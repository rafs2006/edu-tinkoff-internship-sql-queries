--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.0
-- Dumped by pg_dump version 14.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres;
--
-- Name: postgres; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'English_United States.1252';


ALTER DATABASE postgres OWNER TO postgres;

\connect postgres

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: adminpack; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS adminpack WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION adminpack; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION adminpack IS 'administrative functions for PostgreSQL';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: flights; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.flights (
    flight_id integer NOT NULL,
    flight_dt date,
    plane integer,
    first_pilot_id integer,
    second_pilot_id integer,
    destination character varying(3),
    quantity integer
);


ALTER TABLE public.flights OWNER TO postgres;

--
-- Name: flights_flight_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.flights_flight_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.flights_flight_id_seq OWNER TO postgres;

--
-- Name: flights_flight_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.flights_flight_id_seq OWNED BY public.flights.flight_id;


--
-- Name: flights_upd; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.flights_upd (
    second_pilot_id integer,
    cargo_flg boolean,
    plane integer
);


ALTER TABLE public.flights_upd OWNER TO postgres;

--
-- Name: pilots; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pilots (
    pilot_id integer NOT NULL,
    name character varying(30),
    age integer,
    rank character varying(30),
    education_level character varying(30)
);


ALTER TABLE public.pilots OWNER TO postgres;

--
-- Name: pilots_pilot_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pilots_pilot_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pilots_pilot_id_seq OWNER TO postgres;

--
-- Name: pilots_pilot_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pilots_pilot_id_seq OWNED BY public.pilots.pilot_id;


--
-- Name: planes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.planes (
    plane_id integer NOT NULL,
    capacity integer,
    cargo_flg boolean
);


ALTER TABLE public.planes OWNER TO postgres;

--
-- Name: planes_plane_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.planes_plane_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.planes_plane_id_seq OWNER TO postgres;

--
-- Name: planes_plane_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.planes_plane_id_seq OWNED BY public.planes.plane_id;


--
-- Name: flights flight_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flights ALTER COLUMN flight_id SET DEFAULT nextval('public.flights_flight_id_seq'::regclass);


--
-- Name: pilots pilot_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pilots ALTER COLUMN pilot_id SET DEFAULT nextval('public.pilots_pilot_id_seq'::regclass);


--
-- Name: planes plane_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.planes ALTER COLUMN plane_id SET DEFAULT nextval('public.planes_plane_id_seq'::regclass);


--
-- Data for Name: flights; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.flights (flight_id, flight_dt, plane, first_pilot_id, second_pilot_id, destination, quantity) FROM stdin;
\.
COPY public.flights (flight_id, flight_dt, plane, first_pilot_id, second_pilot_id, destination, quantity) FROM '$$PATH$$/3335.dat';

--
-- Data for Name: flights_upd; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.flights_upd (second_pilot_id, cargo_flg, plane) FROM stdin;
\.
COPY public.flights_upd (second_pilot_id, cargo_flg, plane) FROM '$$PATH$$/3336.dat';

--
-- Data for Name: pilots; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pilots (pilot_id, name, age, rank, education_level) FROM stdin;
\.
COPY public.pilots (pilot_id, name, age, rank, education_level) FROM '$$PATH$$/3331.dat';

--
-- Data for Name: planes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.planes (plane_id, capacity, cargo_flg) FROM stdin;
\.
COPY public.planes (plane_id, capacity, cargo_flg) FROM '$$PATH$$/3333.dat';

--
-- Name: flights_flight_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.flights_flight_id_seq', 1, false);


--
-- Name: pilots_pilot_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pilots_pilot_id_seq', 1, false);


--
-- Name: planes_plane_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.planes_plane_id_seq', 1, false);


--
-- Name: flights flights_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flights
    ADD CONSTRAINT flights_pkey PRIMARY KEY (flight_id);


--
-- Name: pilots pilots_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pilots
    ADD CONSTRAINT pilots_pkey PRIMARY KEY (pilot_id);


--
-- Name: planes planes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.planes
    ADD CONSTRAINT planes_pkey PRIMARY KEY (plane_id);


--
-- Name: flights flights_first_pilot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flights
    ADD CONSTRAINT flights_first_pilot_id_fkey FOREIGN KEY (first_pilot_id) REFERENCES public.pilots(pilot_id);


--
-- Name: flights flights_plane_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flights
    ADD CONSTRAINT flights_plane_fkey FOREIGN KEY (plane) REFERENCES public.planes(plane_id);


--
-- Name: flights flights_second_pilot_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flights
    ADD CONSTRAINT flights_second_pilot_id_fkey FOREIGN KEY (second_pilot_id) REFERENCES public.pilots(pilot_id);


--
-- Name: TABLE flights; Type: ACL; Schema: public; Owner: postgres
--

GRANT REFERENCES,DELETE,TRIGGER,TRUNCATE ON TABLE public.flights TO pg_read_all_data;
GRANT SELECT,INSERT,UPDATE ON TABLE public.flights TO pg_read_all_data WITH GRANT OPTION;


--
-- Name: TABLE flights_upd; Type: ACL; Schema: public; Owner: postgres
--

GRANT REFERENCES,DELETE,TRIGGER,TRUNCATE ON TABLE public.flights_upd TO pg_read_all_data;
GRANT SELECT,INSERT,UPDATE ON TABLE public.flights_upd TO pg_read_all_data WITH GRANT OPTION;


--
-- Name: TABLE pilots; Type: ACL; Schema: public; Owner: postgres
--

GRANT REFERENCES,DELETE,TRIGGER,TRUNCATE ON TABLE public.pilots TO pg_read_all_data;
GRANT SELECT,INSERT,UPDATE ON TABLE public.pilots TO pg_read_all_data WITH GRANT OPTION;


--
-- Name: TABLE planes; Type: ACL; Schema: public; Owner: postgres
--

GRANT REFERENCES,DELETE,TRIGGER,TRUNCATE ON TABLE public.planes TO pg_read_all_data;
GRANT SELECT,INSERT,UPDATE ON TABLE public.planes TO pg_read_all_data WITH GRANT OPTION;


--
-- PostgreSQL database dump complete
--

